Terrence Alsup

March 27, 2019
Monte Carlo Methods HW 3

The following four Python files are included:

IsingSamplers.py
ex39.py
ex42.py
ex43.py

The last 3 produce the plots for exercises 39,42, and 43 respectively.

WARNING!: The files ex39.py and ex42.py take a very long time to run.  If you want to run these
I suggest changing the parameters in the code to make the chains shorter.

To run and compile any of the files simply go to command line in the directory containing the files and type:

python FILE_NAME.py

where FILE_NAME is replaced appropriately.  The code uses Anaconda 3, which can be loaded on a CIMS desktop by calling

module load anaconda3

These files have the following Python package dependencies:

numpy==1.15.4
matplotlib==3.0.3
acor==1.1.1



